<?php

namespace App\Http\Requests\Courses;

use App\Enums\MediaType;
use App\Support\PricePlans;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreCourseRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    protected function prepareForValidation(): void
    {
        foreach (['category_id', 'subject_id', 'instructor_id'] as $field) {
            if ($this->input($field) === '') {
                $this->merge([$field => null]);
            }
        }

        $this->merge([
            'is_featured' => $this->boolean('is_featured'),
            'is_trial_available' => $this->boolean('is_trial_available'),
            'plans' => PricePlans::normalizeInput($this->input('plans')),
        ]);
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'category_id' => ['nullable', 'integer', 'exists:categories,id'],
            'subject_id' => ['nullable', 'integer', 'exists:subjects,id'],
            'instructor_id' => ['nullable', 'integer', 'exists:instructors,id'],
            'name' => ['required', 'string', 'max:255'],
            'short_description' => ['nullable', 'string'],
            'description' => ['nullable', 'string'],
            'thumbnail' => MediaType::CourseThumbnail->rules(),
            'banner' => MediaType::CourseBanner->rules(),
            'status' => ['required', Rule::in(['draft', 'published', 'inactive'])],
            'is_featured' => ['boolean'],
            'is_trial_available' => ['boolean'],
            ...PricePlans::rules(),
        ];
    }

    /**
     * @return array<string, string>
     */
    public function messages(): array
    {
        return PricePlans::messages();
    }

    /**
     * @return array<string, string>
     */
    public function attributes(): array
    {
        return PricePlans::attributes();
    }
}
